import { Router } from 'express';
import {
    createAuthorController,
    assingBookToAuthorController,
    deleteAuthorController,
    getAllAuthors
} from '../controllers/author.controller.js';

const authorRouter = Router();

authorRouter.post('/create', createAuthorController);
authorRouter.delete('/:id', deleteAuthorController);
authorRouter.get('/', getAllAuthorsController);

export { authorRouter };